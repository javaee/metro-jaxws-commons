
// define the namespaces
jmaki.namespace("jmaki.widgets.yahoo.grid");

jmaki.widgets.yahoo.grid.Widget = function(wargs) {
    
    var container = document.getElementById(wargs.uuid);
    var self = this;
    var _model;
    var grid;
    var cm;
 
    var data;
    var cols = [];
    var cold;
    if (wargs.args && wargs.args.columns) {
        cold =   wargs.args.columns;
    }
    var schema = [];

    
    if (wargs.value) {
        data = wargs.value;
        init();
    } else if (wargs.service) {
        jmaki.doAjax({url: wargs.service, callback: function(req) {
            if (req.readyState == 4) {
                if (req.status == 200) {
                    var _in = eval('(' + req.responseText + ')');
                    if (_in.rows) {
                        data = _in.rows;
                    }  else {
                        data = _in;
                    }
                    if (!cold && _in.columns) {
                        cold = _in.columns;
                    }
                    init();
                }
            }
        }});
    }

    function init() {
        // create the columns and editors
        for (var i = 0 ; i < cold.length; i++){
            var col = {};
            
            schema.push(cold[i].title);
            // mix in everything but the renderer and editor
            for (var ii in cold[i]) {
                if (ii == 'editor') {
                    // create new editor with the mixins
                    col.editor = cold[i].editor;
                } else if (ii == 'renderer') {      
                    col.renderer = cold[i].renderer;                  
                } else if (ii == 'title') {    
                    col.key = cold[i].title; 
                } else {
                    col[ii] = cold[i][ii];
                }
            }
            if (!col.sortable) col.sortable = true;
            cols.push(col);
        }
        
        var nData = [];
        // normalize data for yahoo which wants key value pairs for every row item
        for (var i=0; i < data.length; i++) {
            var row = {};
            for (var ii=0; ii < data[i].length; ii++) {
                row[schema[ii]] = data[i][ii];
            }
            nData.push(row);
        }
        
        var columns = new YAHOO.widget.ColumnSet(cols);
        
        var ds = new YAHOO.util.DataSource(nData);
        ds.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
        ds.responseSchema = {fields :schema};
        
        
        var onCellEdit = function(oArgs) {
            alert("cel edit");
            YAHOO.log("Cell \"" + oArgs.target.id +
            "\" was updated from \"" + oArgs.oldData + "\" to \"" +
            oArgs.newData + "\"", "info", this.toString());
        }
        
        var grid = new YAHOO.widget.DataTable(wargs.uuid, columns, ds,{caption:""});
        grid.subscribe("cellClickEvent",grid.onEventEditCell);
        grid.subscribe("cellMouseoverEvent",grid.onEventHighlightCell);
        grid.subscribe("cellMouseoutEvent",grid.onEventUnhighlightCell);
        
        grid.subscribe("cellEditEvent",function() {alert("cell edit here")});
    }
}