dojo.require("dojo.widget.FilteringTable");

// define the namespaces
jmaki.namespace("jmaki.widgets.dojo.table");

jmaki.widgets.dojo.table.Widget = function(wargs) {

    var self = this;
    var columns = [];
    this.rows = [];
    var uuid = wargs.uuid;
    var topic = "/dojo/table";
    var filter = "jmaki.filters.tableFilter";
    var auto = true;
    
    if (wargs.args) {
        if (wargs.args.topic) {
            topic = wargs.args.topic;
        }
        if (wargs.args.filter) {
           filter = wargs.args.filter;
        }        
        if (wargs.args.auto) {
            auto = (wargs.args.auto == 'true');
        }
    }
    
    var container = document.getElementById(uuid);
    var table;
    var count = self.rows.length;
    var columnNames = [];
    var lColumns = [];
    
    
    // initialize the widget
    this.init = function() {
        // backwards compatibility
        if (typeof columns[0] == 'object') {      
             var c = [];
             for (var i in columns) {
                 c.push(columns[i].title);
             } 
            columns = c;
        }          
        if (!auto) {
            table = dojo.widget.createWidget(container);
        } else {
            table = dojo.widget.createWidget("FilteringTable",{valueField: "Id"},container);
            // provide generic column names if they were not provided.
            if (typeof columns == "undefined") {
                for (var l = 0; l < count; l++) {
                    columnNames.push({ field: "col_" + l, label: "Column " + l,  dataType:"String" });
                }
            }
            // now build up the list of titles
            for (var l in columns) {
                var ct = columns[l];
                var cType = "string";
                // we want to only allow for specifc number and string types
                // this could be an array or object and we want to prevent
                if (typeof ct == "string") {
                } else if (typeof ct == "number") {
                    cType = "number";
                }
                lColumns.push({ field: l, label: ct,  dataType:cType });
                columnNames.push(l);
            }
        }
        
        for (var x = 0; x < lColumns.length; x++) {
            table.columns.push(table.createMetaData(lColumns[x]));
        }
        
        var data = [];
        // add an Id for everything as it is needed for sorting
        for (var i=0; i < self.rows.length; i++) {
            var nRow = {};
            if (typeof self.rows[i].Id == "undefined") {
                nRow.Id = i;
            } else {
                nRow.Id = self.rows.Id;  
            }
            for (var cl = 0; cl < columnNames.length; cl++) {     
                nRow[columnNames[cl]] = self.rows[i][cl];
            }
            data.push(nRow);   
        }
        table.store.setData(data);
    }
    
    // set columns from the widget arguments if provided.
    if (wargs.args && wargs.args.columns) {
        if (typeof wargs.args.columns[0] == 'object') {
            for (var i = 0; i < wargs.args.columns.length; i++) {        
                columns.push(wargs.args.columns[i].title);
            } 
        } else {
            columns = wargs.args.columns;
        }        
    }
    // pull in the arguments
    if (wargs.value) {
        // convert value if a jmakiRSS type
        if (wargs.value.dataType == 'jmakiRSS') {
           wargs.value = jmaki.filter(wargs.value, filter);
        }
        if (typeof wargs.value.rows == "object"){
            self.rows = wargs.value.rows;
        } else {
            self.rows = wargs.value;
        }
        if (wargs.value.columns) {
            columns = wargs.value.columns;
        }
        self.init();
        
    } else if (wargs.service) {
        
        var _w = wargs;
        dojo.io.bind({
            url: wargs.service,
            method: "get",
            mimetype: "text/json",
            load: function (type,data,evt) {
                if (data == false) {
                    container.innerHTML = "Data format error loading data from " + wargs.service;
                } else {
                    // convert value if a jmakiRSS type
                    if (data.dataType == 'jmakiRSS') {
                        data = jmaki.filter(data, filter);
                    }
                    if (data.rows) {
                        self.rows = data.rows;                   
                    } else if (data == "object"){
                        self.rows = data;
                    }
                    if (data.columns) {
                       columns = data.columns;
                    }
                    self.init();
                }
            }
        });
    } else {
        if (columns.length == 0) columns = 
        [
         { "title" : "Title"},
         { "title":"Author"},
         { "title": "ISBN #"},
         { "title":"Description"}
        ];
        // default data
        self.rows = [
        ['Book Title 1', 'Author 1', '4412', 'A Some long description'],
        ['Book Title 2', 'Author 2', '4413','B Some long description'],
        ['Book Title 3', 'Author 3',  '4414','C Some long description'],
        ['Book Title 4', 'Author 4','4415','D Some long description']
        ]
        self.init();
    }
    
    this.clearFilters = function(){
        table.clearFilters();
    }
    
    this.addRow = function(b){
        // add an id for sorting if not defined
        if (typeof b.Id == "undefined") {      
            b.Id = count++;
        }
        table.store.addData(b);
    }
}